package ippo.assignment2.controller;

public interface Controller {
    void start();

    void select(String commandWord);
}
